import asyncio
import random
import time
import numpy as np
import os
import sys
import pandas as pd
from exampleDevice import Device

# ----------------
# producer section
# ----------------
async def main(CSV_FILE, STREAM_NAME):
    device = Device('LINAC:BCM1', 'brianna_redis')
    await device.initialize()
    numpy_data = np.genfromtxt(CSV_FILE, dtype=np.int16)

    stream_key = f"{device.base_key}:{STREAM_NAME}" 
    binary_field = '_'
    data_type_field = 'TYPE'
    data_type = 'INT16'
    
    data_point = {binary_field: numpy_data, data_type_field: data_type}
    await device.redis_adapter.streamAdd(stream_key, data_point, maxlen=10)

if __name__ == "__main__":
    # read in arguments
    if len(sys.argv) < 3:
        #print("Usage: script.py <CSV_FILE> <STREAM_NAME>")
        sys.exit(1)

    # Read in arguments
    CSV_FILE = sys.argv[1]
    STREAM_NAME = sys.argv[2]

    # Run the asynchronous main function
    asyncio.run(main(CSV_FILE, STREAM_NAME))
